"""
Mindustry Launcher - лаунчер для игры Mindustry
В стиле TLauncher
"""

import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox, filedialog
import requests
import os
import subprocess
import threading
import json
from pathlib import Path
import getpass
import shutil
import sys

# Настройки внешнего вида
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# Цветовая схема
COLOR_PRIMARY = "#FF6B35"      # Оранжевый акцент
COLOR_PRIMARY_HOVER = "#FF8C5A"
COLOR_SECONDARY = "#1E1E2E"    # Тёмный фон
COLOR_SURFACE = "#2D2D3F"      # Поверхность
COLOR_SUCCESS = "#4CAF50"      # Зелёный
COLOR_SUCCESS_HOVER = "#66BB6A"
COLOR_TEXT = "#FFFFFF"
COLOR_TEXT_SECONDARY = "#A0A0A0"

# Переводы
TRANSLATIONS = {
    "en": {
        "title": "MindLauncher",
        "subtitle": "MindLauncher by Feltyhides",
        "tagline": "Convenient launcher for your favorite game",
        "select_version": "Select Version:",
        "show_downloaded": "Show only downloaded versions",
        "download": "⬇ DOWNLOAD",
        "launch": "▶ LAUNCH",
        "loading": "Loading...",
        "no_versions": "No versions available",
        "no_downloaded": "No downloaded versions",
        "select_version_text": "Select a version",
        "launcher_folder": "📁 Launcher Folder:",
        "open": "Open",
        "jvm_args": "⚙️ JVM Arguments:",
        "jvm_placeholder": "-Xmx2G -Xms1G",
        "ram_settings": "Memory Settings",
        "footer": "📦 GitHub Releases  •  🌐 Official Site  •  ✨ MindLauncher by Feltyhides",
        "downloading": "Connecting...",
        "download_complete": "✅ Downloaded!",
        "launching": "🚀 Launching...",
        "launched": "✅ Game launched",
        "java_not_found": "Java not found!\nPlease install Java 8 or higher.",
        "file_not_found": "Game file not found!",
        "download_error": "Download failed",
        "launch_error": "Failed to launch game",
        "exit_title": "Exit",
        "exit_message": "Game is running. Close launcher?",
        "open_official_site": "Opening official site...",
        # First run wizard
        "welcome": "Welcome to MindLauncher!",
        "welcome_text": "Thank you for choosing MindLauncher.\nLet's set up a few things to get started.",
        "select_language": "Select Language / Выберите язык:",
        "java_check": "Java Check",
        "java_required": "Java is required to run Mindustry.",
        "java_installed": "✅ Java is installed!",
        "java_not_installed": "⚠️ Java is not detected.",
        "install_java_manually": "Please install Java 8 or higher manually.",
        "download_java": "Download Java (Oracle)",
        "skip_java": "I'll install later",
        "finish": "Finish Setup",
        "finishing": "Completing...",
        "setup_complete": "Setup Complete!",
        "setup_complete_text": "Everything is ready! Click 'Finish' to start using MindLauncher.",
    },
    "ru": {
        "title": "MindLauncher",
        "subtitle": "MindLauncher by Feltyhides",
        "tagline": "Удобный лаунчер для вашей любимой игры",
        "select_version": "Выберите версию:",
        "show_downloaded": "Показывать только скачанные версии",
        "download": "⬇ СКАЧАТЬ",
        "launch": "▶ ЗАПУСТИТЬ",
        "loading": "Загрузка...",
        "no_versions": "Нет доступных версий",
        "no_downloaded": "Нет скачанных версий",
        "select_version_text": "Выберите версию",
        "launcher_folder": "📁 Папка лаунчера:",
        "open": "Открыть",
        "jvm_args": "⚙️ Аргументы JVM:",
        "jvm_placeholder": "-Xmx2G -Xms1G",
        "ram_settings": "Настройки памяти",
        "footer": "📦 GitHub релизы  •  🌐 Официальный сайт  •  ✨ MindLauncher by Feltyhides",
        "downloading": "Соединение...",
        "download_complete": "✅ Скачано!",
        "launching": "🚀 Запуск...",
        "launched": "✅ Игра запущена",
        "java_not_found": "Java не найдена!\nУстановите Java 8 или выше.",
        "file_not_found": "Файл игры не найден!",
        "download_error": "Ошибка скачивания",
        "launch_error": "Не удалось запустить игру",
        "exit_title": "Выход",
        "exit_message": "Игра запущена. Закрыть лаунчер?",
        "open_official_site": "Открытие официального сайта...",
        # First run wizard
        "welcome": "Добро пожаловать в MindLauncher!",
        "welcome_text": "Спасибо за выбор MindLauncher.\nДавайте настроим несколько вещей для начала работы.",
        "select_language": "Select Language / Выберите язык:",
        "java_check": "Проверка Java",
        "java_required": "Java необходим для запуска Mindustry.",
        "java_installed": "✅ Java установлен!",
        "java_not_installed": "⚠️ Java не обнаружен.",
        "install_java_manually": "Пожалуйста, установите Java 8 или выше вручную.",
        "download_java": "Скачать Java (Oracle)",
        "skip_java": "Установлю позже",
        "finish": "Завершить настройку",
        "finishing": "Завершение...",
        "setup_complete": "Настройка завершена!",
        "setup_complete_text": "Всё готово! Нажмите 'Завершить' для начала использования MindLauncher.",
    }
}

def migrate_to_data_dir():
    """Перенос файлов лаунчера в папку данных"""
    user_name = getpass.getuser()
    data_dir = Path(f"C:/Users/{user_name}/MindLauncher")
    
    # Текущая папка и папка данных
    current_dir = Path(__file__).parent.resolve()
    
    # Если уже в папке данных - ничего не делаем
    if current_dir == data_dir:
        return data_dir
    
    # Создаём папку данных
    data_dir.mkdir(exist_ok=True)
    
    # Копируем launcher.py
    source_launcher = current_dir / "launcher.py"
    target_launcher = data_dir / "launcher.py"
    
    if source_launcher.exists() and not source_launcher.samefile(target_launcher):
        try:
            shutil.copy2(source_launcher, target_launcher)
        except:
            pass
    
    # Копируем иконку (ICO и PNG)
    for icon_name in ["icon.ico", "icon.png"]:
        source_icon = current_dir / icon_name
        target_icon = data_dir / icon_name
        
        if source_icon.exists():
            try:
                shutil.copy2(source_icon, target_icon)
            except:
                pass
    
    # Копируем .exe если он есть
    source_exe = current_dir / "MindustryLauncher.exe"
    target_exe = data_dir / "MindustryLauncher.exe"
    
    if source_exe.exists():
        try:
            # Не копируем, если это тот же файл
            if not source_exe.samefile(target_exe):
                shutil.copy2(source_exe, target_exe)
        except:
            pass
    
    return data_dir

class FirstRunWizard(ctk.CTk):
    """Окно первого запуска с выбором языка и проверкой Java"""
    
    def __init__(self):
        super().__init__()
        
        self.data_dir = Path(f"C:/Users/{getpass.getuser()}/MindLauncher")
        self.data_dir.mkdir(exist_ok=True)
        self.lang_file = self.data_dir / "lang.json"
        
        # По умолчанию английский
        self.current_lang = 'en'
        
        # Настройки окна
        self.title("MindLauncher - Setup")
        self.geometry("600x500")
        self.resizable(False, False)

        # Переменные
        self.java_installed = False

        self.create_ui()
        self.check_java()
    
    def t(self, key):
        """Получение перевода"""
        return TRANSLATIONS.get(self.current_lang, TRANSLATIONS['en']).get(key, key)
    
    def create_ui(self):
        """Создание интерфейса мастера настройки"""
        
        # Главный фрейм
        self.main_frame = ctk.CTkFrame(self, fg_color=COLOR_SECONDARY)
        self.main_frame.pack(fill="both", expand=True)
        
        # Заголовок
        self.header_frame = ctk.CTkFrame(self.main_frame, fg_color=COLOR_SURFACE, height=100)
        self.header_frame.pack(fill="x", padx=0, pady=0)
        self.header_frame.pack_propagate(False)
        
        self.title_label = ctk.CTkLabel(
            self.header_frame,
            text="⬡ MINDUSTRY",
            font=ctk.CTkFont(size=32, weight="bold"),
            text_color=COLOR_PRIMARY
        )
        self.title_label.pack(pady=(20, 5))
        
        self.subtitle_label = ctk.CTkLabel(
            self.header_frame,
            text=self.t("welcome"),
            font=ctk.CTkFont(size=16),
            text_color=COLOR_TEXT
        )
        self.subtitle_label.pack()
        
        # Контент
        self.content_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.content_frame.pack(fill="both", expand=True, padx=40, pady=30)
        
        # Выбор языка
        self.lang_label = ctk.CTkLabel(
            self.content_frame,
            text=self.t("select_language"),
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLOR_TEXT
        )
        self.lang_label.pack(pady=(0, 10))
        
        self.lang_var = tk.StringVar(value="en")
        self.lang_dropdown = ctk.CTkOptionMenu(
            self.content_frame,
            variable=self.lang_var,
            values=["en", "ru"],
            command=self.change_language,
            font=ctk.CTkFont(size=14),
            height=40,
            button_color=COLOR_PRIMARY,
            button_hover_color=COLOR_PRIMARY_HOVER,
            fg_color=COLOR_SURFACE,
            dropdown_fg_color=COLOR_SURFACE
        )
        self.lang_dropdown.pack(fill="x", pady=(0, 20))
        
        # Проверка Java
        self.java_frame = ctk.CTkFrame(self.content_frame, fg_color=COLOR_SURFACE, corner_radius=10)
        self.java_frame.pack(fill="x", pady=10)
        
        self.java_title = ctk.CTkLabel(
            self.java_frame,
            text=self.t("java_check"),
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=COLOR_TEXT
        )
        self.java_title.pack(pady=(15, 5))
        
        self.java_required_label = ctk.CTkLabel(
            self.java_frame,
            text=self.t("java_required"),
            font=ctk.CTkFont(size=12),
            text_color=COLOR_TEXT_SECONDARY
        )
        self.java_required_label.pack(pady=(0, 10))
        
        self.java_status = ctk.CTkLabel(
            self.java_frame,
            text="⏳ " + self.t("java_check") + "...",
            font=ctk.CTkFont(size=14),
            text_color=COLOR_TEXT
        )
        self.java_status.pack(pady=10)
        
        # Кнопки Java
        self.java_buttons_frame = ctk.CTkFrame(self.java_frame, fg_color="transparent")
        self.java_buttons_frame.pack(pady=(0, 15))

        self.download_java_btn = ctk.CTkButton(
            self.java_buttons_frame,
            text=self.t("download_java"),
            command=self.download_java,
            font=ctk.CTkFont(size=14, weight="bold"),
            height=40,
            fg_color=COLOR_PRIMARY,
            hover_color=COLOR_PRIMARY_HOVER,
            width=140
        )
        self.download_java_btn.pack(side="left", padx=5)

        self.skip_java_btn = ctk.CTkButton(
            self.java_buttons_frame,
            text=self.t("skip_java"),
            command=self.skip_java,
            font=ctk.CTkFont(size=14),
            height=40,
            fg_color="transparent",
            hover_color=COLOR_SURFACE,
            width=140
        )
        self.skip_java_btn.pack(side="left", padx=5)
        
        # Кнопка "Пропустить проверку"
        self.skip_check_btn = ctk.CTkButton(
            self.java_buttons_frame,
            text="⏭ " + self.t("finish"),
            command=self.skip_check,
            font=ctk.CTkFont(size=14),
            height=40,
            fg_color=COLOR_SUCCESS,
            hover_color=COLOR_SUCCESS_HOVER,
            width=160
        )
        self.skip_check_btn.pack(side="left", padx=5)

        # Кнопка завершения
        self.finish_btn = ctk.CTkButton(
            self.content_frame,
            text=self.t("finish"),
            command=self.finish_setup,
            font=ctk.CTkFont(size=16, weight="bold"),
            height=50,
            fg_color=COLOR_SUCCESS,
            hover_color=COLOR_SUCCESS_HOVER,
            state="disabled"
        )
        self.finish_btn.pack(fill="x", pady=20)
    
    def change_language(self, lang):
        """Смена языка"""
        self.current_lang = lang
        self.update_texts()
    
    def update_texts(self):
        """Обновление текстов"""
        self.subtitle_label.configure(text=self.t("welcome"))
        self.lang_label.configure(text=self.t("select_language"))
        self.java_title.configure(text=self.t("java_check"))
        self.java_required_label.configure(text=self.t("java_required"))
        if self.java_installed:
            self.java_status.configure(text=self.t("java_installed"))
        else:
            self.java_status.configure(text=self.t("install_java_manually"))
        self.download_java_btn.configure(text=self.t("download_java"))
        self.skip_java_btn.configure(text=self.t("skip_java"))
        self.skip_check_btn.configure(text="⏭ " + self.t("finish"))
        self.finish_btn.configure(text=self.t("finish"))
    
    def check_java(self):
        """Проверка наличия Java"""
        java_path = self.find_java()
        if java_path:
            self.java_status.configure(text=self.t("java_installed"), 
                                       text_color=COLOR_SUCCESS)
            self.java_installed = True
            self.finish_btn.configure(state="normal")
            self.download_java_btn.configure(state="disabled")
        else:
            self.java_status.configure(text=self.t("install_java_manually"),
                                       text_color=COLOR_PRIMARY)
            self.java_installed = False
    
    def find_java(self):
        """Поиск Java"""
        java_home = os.environ.get("JAVA_HOME")
        if java_home:
            java_exe = Path(java_home) / "bin" / "java.exe"
            if java_exe.exists():
                return str(java_exe)
        
        try:
            result = subprocess.run(["java", "-version"], capture_output=True, timeout=5)
            if result.returncode == 0:
                return "java"
        except:
            pass
        
        possible_paths = [
            r"C:\Program Files\Java\jdk\bin\java.exe",
            r"C:\Program Files\Java\jre\bin\java.exe",
            r"C:\Program Files (x86)\Java\jdk\bin\java.exe",
        ]
        
        for path in possible_paths:
            if Path(path).exists():
                return path
        
        return None
    
    def download_java(self):
        """Открытие страницы загрузки Java"""
        import webbrowser
        webbrowser.open("https://www.oracle.com/java/technologies/downloads/")
        # Включаем кнопку завершения
        self.finish_btn.configure(state="normal")
        self.download_java_btn.configure(state="disabled")
        self.skip_java_btn.configure(state="disabled")

    def skip_java(self):
        """Пропустить установку Java"""
        self.finish_btn.configure(state="normal")
        self.download_java_btn.configure(state="disabled")
        self.skip_java_btn.configure(state="disabled")
        self.skip_check_btn.configure(state="disabled")
    
    def skip_check(self):
        """Пропустить проверку и завершить настройку"""
        self.finish_setup()
    
    def finish_setup(self):
        """Завершение настройки"""
        self.finish_btn.configure(text=self.t("finishing"), state="disabled")

        # Сохраняем язык и настройки
        try:
            config = {
                'lang': self.current_lang,
                'ram_min': 512,
                'ram_max': 2048,
                'fullscreen': False
            }
            with open(self.lang_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2)
        except:
            pass

        # Показываем финальное сообщение
        messagebox.showinfo(self.t("setup_complete"), self.t("setup_complete_text"))

        # Закрываем мастер и открываем основной лаунчер
        self.destroy()

        # Запускаем основной лаунчер
        app = MindustryLauncher()
        app.protocol("WM_DELETE_WINDOW", app.on_closing)
        app.mainloop()


class MindustryLauncher(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Миграция файлов
        self.data_dir = migrate_to_data_dir()
        self.versions_dir = self.data_dir / "versions"
        self.versions_dir.mkdir(exist_ok=True)

        # Основные настройки окна
        self.title("MindLauncher")
        self.geometry("1000x650")
        self.minsize(900, 600)

        # Пути
        self.base_dir = Path(__file__).parent.resolve()
        self.user_name = getpass.getuser()

        # Язык (по умолчанию английский)
        self.lang_file = self.data_dir / "lang.json"
        self.config = self.load_config()
        self.current_lang = self.config.get('lang', 'en')

        # Переменные
        self.versions = []
        self.selected_version = tk.StringVar(value=self.t("loading"))
        self.download_status = tk.StringVar(value="")
        self.is_downloading = False
        self.current_process = None

        # Загрузка версий
        self.load_versions()

        # Установка иконки окна
        self.set_window_icon()

        # Создание интерфейса
        self.create_ui()
    
    def load_config(self):
        """Загрузка конфигурации"""
        default_config = {
            'lang': 'en',
            'ram_min': 512,
            'ram_max': 2048,
            'fullscreen': False
        }
        try:
            if self.lang_file.exists():
                with open(self.lang_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    # Объединяем с дефолтными значениями
                    for key, value in default_config.items():
                        if key not in config:
                            config[key] = value
                    return config
        except:
            pass
        return default_config
    
    def save_config(self):
        """Сохранение конфигурации"""
        try:
            with open(self.lang_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2)
        except:
            pass
    
    def t(self, key):
        """Получение перевода"""
        return TRANSLATIONS.get(self.current_lang, TRANSLATIONS['en']).get(key, key)
    
    def set_language(self, lang):
        """Установка языка"""
        if lang in TRANSLATIONS:
            self.current_lang = lang
            self.save_language(lang)
            # Обновляем текст на элементах
            self.update_ui_texts()
    
    def update_ui_texts(self):
        """Обновление всех текстов на интерфейсе"""
        # Header
        self.subtitle_label.configure(text=self.t("subtitle"))
        self.version_label_sub.configure(text=self.t("tagline"))
        
        # Version selection
        self.version_label.configure(text=self.t("select_version"))
        self.show_downloaded_cb.configure(text=self.t("show_downloaded"))
        
        # Action button
        self.update_action_button()
        
        # Settings
        for widget in self.path_frame.winfo_children():
            if isinstance(widget, ctk.CTkLabel) and widget.cget("text"):
                widget.configure(text=self.t("launcher_folder"))
                break
        
        self.open_path_btn.configure(text=self.t("open"))
        
        for widget in self.jvm_frame.winfo_children():
            if isinstance(widget, ctk.CTkLabel) and widget.cget("text"):
                widget.configure(text=self.t("jvm_args"))
                break
        
        # Footer
        self.github_link.configure(text=self.t("footer"))
        
        # Update lang dropdown
        self.lang_var.set(self.current_lang)
        
    def set_window_icon(self):
        """Установка иконки окна"""
        # Пробуем разные варианты
        icon_paths = [
            self.base_dir / "icon.ico",
            self.base_dir / "icon.png",
        ]
        
        for icon_path in icon_paths:
            if icon_path.exists():
                try:
                    # Для customtkinter/tkinter
                    icon_img = tk.PhotoImage(file=str(icon_path))
                    self.iconphoto(True, icon_img)
                    return
                except:
                    pass
        
        # Если не получилось, пробуем стандартный метод
        try:
            self.iconbitmap(str(icon_paths[0]))
        except:
            pass
        
    def create_ui(self):
        """Создание основного интерфейса"""

        # Главный фрейм с градиентным фоном
        self.main_frame = ctk.CTkFrame(self, corner_radius=0, fg_color=COLOR_SECONDARY)
        self.main_frame.pack(fill="both", expand=True)

        # Верхняя панель с логотипом
        self.header_frame = ctk.CTkFrame(self.main_frame, height=140, corner_radius=0,
                                         fg_color=COLOR_SURFACE)
        self.header_frame.pack(fill="x", padx=0, pady=0)
        self.header_frame.pack_propagate(False)

        # Логотип с эмодзи
        self.logo_label = ctk.CTkLabel(
            self.header_frame,
            text="⬡ MINDUSTRY",
            font=ctk.CTkFont(size=42, weight="bold"),
            text_color=COLOR_PRIMARY
        )
        self.logo_label.pack(pady=(25, 5))

        # Подзаголовок с подписью автора
        self.subtitle_label = ctk.CTkLabel(
            self.header_frame,
            text=self.t("subtitle"),
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=COLOR_TEXT
        )
        self.subtitle_label.pack()

        self.version_label_sub = ctk.CTkLabel(
            self.header_frame,
            text=self.t("tagline"),
            font=ctk.CTkFont(size=12),
            text_color=COLOR_TEXT_SECONDARY
        )
        self.version_label_sub.pack()
        
        # Переключатель языка
        self.lang_frame = ctk.CTkFrame(self.header_frame, fg_color="transparent")
        self.lang_frame.pack(side="right", padx=20, pady=10)
        
        self.lang_label = ctk.CTkLabel(
            self.lang_frame,
            text="🌐",
            font=ctk.CTkFont(size=16),
            text_color=COLOR_TEXT_SECONDARY
        )
        self.lang_label.pack(side="left", padx=5)
        
        self.lang_var = tk.StringVar(value=self.current_lang)
        self.lang_dropdown = ctk.CTkOptionMenu(
            self.lang_frame,
            variable=self.lang_var,
            values=["en", "ru"],
            command=self.set_language,
            font=ctk.CTkFont(size=12),
            height=30,
            button_color=COLOR_PRIMARY,
            button_hover_color=COLOR_PRIMARY_HOVER,
            fg_color=COLOR_SECONDARY,
            dropdown_fg_color=COLOR_SURFACE
        )
        self.lang_dropdown.pack(side="left", padx=5)

        # Центральная часть
        self.center_frame = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.center_frame.pack(fill="both", expand=True, padx=80, pady=30)
        
        # Выбор версии
        self.version_frame = ctk.CTkFrame(self.center_frame, fg_color=COLOR_SURFACE,
                                          corner_radius=12)
        self.version_frame.pack(fill="x", pady=10)

        self.version_label = ctk.CTkLabel(
            self.version_frame,
            text=self.t("select_version"),
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=COLOR_TEXT
        )
        self.version_label.pack(pady=(20, 10))

        # Чекбокс "Показывать только скачанные"
        self.show_downloaded_var = tk.BooleanVar(value=True)
        self.show_downloaded_cb = ctk.CTkCheckBox(
            self.version_frame,
            text=self.t("show_downloaded"),
            variable=self.show_downloaded_var,
            command=self.update_version_dropdown,
            font=ctk.CTkFont(size=14),
            text_color=COLOR_TEXT_SECONDARY
        )
        self.show_downloaded_cb.pack(pady=(0, 15))

        self.version_dropdown = ctk.CTkOptionMenu(
            self.version_frame,
            variable=self.selected_version,
            values=[],
            font=ctk.CTkFont(size=16),
            height=50,
            button_color=COLOR_PRIMARY,
            button_hover_color=COLOR_PRIMARY_HOVER,
            fg_color=COLOR_SECONDARY,
            dropdown_fg_color=COLOR_SURFACE
        )
        self.version_dropdown.pack(fill="x", padx=30, pady=(0, 20))

        # Кнопка действия (скачать/запустить)
        self.action_button = ctk.CTkButton(
            self.center_frame,
            text=self.t("loading"),
            command=self.action_click,
            font=ctk.CTkFont(size=22, weight="bold"),
            height=70,
            corner_radius=15,
            fg_color=COLOR_SUCCESS,
            hover_color=COLOR_SUCCESS_HOVER
        )
        self.action_button.pack(fill="x", pady=30)

        # Прогресс бар
        self.progress = ctk.CTkProgressBar(self.center_frame, height=10,
                                           progress_color=COLOR_PRIMARY,
                                           fg_color=COLOR_SURFACE)
        self.progress.pack(fill="x", pady=15)
        self.progress.set(0)

        # Статус
        self.status_label = ctk.CTkLabel(
            self.center_frame,
            textvariable=self.download_status,
            font=ctk.CTkFont(size=13),
            text_color=COLOR_TEXT_SECONDARY
        )
        self.status_label.pack(pady=5)

        # Настройки
        self.settings_frame = ctk.CTkFrame(self.center_frame, fg_color=COLOR_SURFACE,
                                           corner_radius=12)
        self.settings_frame.pack(fill="x", pady=20)

        # Путь к игре
        self.path_frame = ctk.CTkFrame(self.settings_frame, fg_color="transparent")
        self.path_frame.pack(fill="x", padx=15, pady=15)

        ctk.CTkLabel(
            self.path_frame,
            text=self.t("launcher_folder"),
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color=COLOR_TEXT
        ).pack(side="left")

        self.path_label = ctk.CTkLabel(
            self.path_frame,
            text=str(self.data_dir),
            font=ctk.CTkFont(size=12),
            text_color=COLOR_TEXT_SECONDARY,
            wraplength=400
        )
        self.path_label.pack(side="left", padx=15)

        self.open_path_btn = ctk.CTkButton(
            self.path_frame,
            text=self.t("open"),
            width=90,
            height=32,
            corner_radius=8,
            fg_color=COLOR_PRIMARY,
            hover_color=COLOR_PRIMARY_HOVER,
            command=self.open_path
        )
        self.open_path_btn.pack(side="right", padx=10)

        # Настройки памяти (RAM)
        self.ram_frame = ctk.CTkFrame(self.settings_frame, fg_color="transparent")
        self.ram_frame.pack(fill="x", padx=15, pady=15)

        ctk.CTkLabel(
            self.ram_frame,
            text="💾 " + self.t("ram_settings"),
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color=COLOR_TEXT
        ).pack(side="left")

        # Минимум RAM
        ctk.CTkLabel(
            self.ram_frame,
            text="Min:",
            font=ctk.CTkFont(size=13),
            text_color=COLOR_TEXT_SECONDARY
        ).pack(side="left", padx=(20, 5))

        self.ram_min_var = tk.IntVar(value=self.config.get('ram_min', 512))
        self.ram_min_spin = ctk.CTkEntry(
            self.ram_frame,
            textvariable=self.ram_min_var,
            width=70,
            height=30
        )
        self.ram_min_spin.pack(side="left", padx=5)
        ctk.CTkLabel(
            self.ram_frame,
            text="MB",
            font=ctk.CTkFont(size=12),
            text_color=COLOR_TEXT_SECONDARY
        ).pack(side="left", padx=2)

        # Максимум RAM
        ctk.CTkLabel(
            self.ram_frame,
            text="Max:",
            font=ctk.CTkFont(size=13),
            text_color=COLOR_TEXT_SECONDARY
        ).pack(side="left", padx=(15, 5))

        self.ram_max_var = tk.IntVar(value=self.config.get('ram_max', 2048))
        self.ram_max_spin = ctk.CTkEntry(
            self.ram_frame,
            textvariable=self.ram_max_var,
            width=70,
            height=30
        )
        self.ram_max_spin.pack(side="left", padx=5)
        ctk.CTkLabel(
            self.ram_frame,
            text="MB",
            font=ctk.CTkFont(size=12),
            text_color=COLOR_TEXT_SECONDARY
        ).pack(side="left", padx=2)

        # Полноэкранный режим
        self.fullscreen_var = tk.BooleanVar(value=self.config.get('fullscreen', False))
        self.fullscreen_cb = ctk.CTkCheckBox(
            self.ram_frame,
            text="Fullscreen",
            variable=self.fullscreen_var,
            font=ctk.CTkFont(size=13),
            text_color=COLOR_TEXT_SECONDARY
        )
        self.fullscreen_cb.pack(side="right", padx=20)

        # Аргументы JVM (дополнительно)
        self.jvm_frame = ctk.CTkFrame(self.settings_frame, fg_color="transparent")
        self.jvm_frame.pack(fill="x", padx=15, pady=(0, 15))

        ctk.CTkLabel(
            self.jvm_frame,
            text=self.t("jvm_args"),
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color=COLOR_TEXT
        ).pack(side="left")

        self.jvm_entry = ctk.CTkEntry(
            self.jvm_frame,
            placeholder_text=self.t("jvm_placeholder"),
            width=350,
            height=35,
            corner_radius=8,
            border_color=COLOR_PRIMARY,
            fg_color=COLOR_SECONDARY
        )
        self.jvm_entry.pack(side="left", padx=15)

        # Нижняя панель
        self.footer_frame = ctk.CTkFrame(self.main_frame, height=60, corner_radius=0,
                                         fg_color=COLOR_SURFACE)
        self.footer_frame.pack(fill="x", side="bottom")
        self.footer_frame.pack_propagate(False)

        # Ссылки
        self.github_link = ctk.CTkLabel(
            self.footer_frame,
            text=self.t("footer"),
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COLOR_PRIMARY,
            cursor="hand2"
        )
        self.github_link.pack(pady=20)
        self.github_link.bind("<Button-1>", lambda e: self.open_url("https://github.com/Anuken/Mindustry/releases"))
        
    def load_versions(self):
        """Загрузка списка версий с GitHub"""
        def fetch():
            try:
                url = "https://api.github.com/repos/Anuken/Mindustry/releases"
                headers = {
                    "User-Agent": "MindustryLauncher/1.0",
                    "Accept": "application/vnd.github.v3+json"
                }
                response = requests.get(url, headers=headers, timeout=10)
                response.raise_for_status()

                releases = response.json()
                versions = []

                for release in releases:
                    tag = release.get("tag_name", "")
                    name = release.get("name", "")

                    # Фильтруем только версии с v
                    if tag.startswith("v"):
                        version_num = tag[1:]  # Убираем 'v'
                        versions.append({
                            "tag": tag,
                            "name": name or tag,
                            "version": version_num
                        })

                self.versions = versions

                # Обновляем UI в главном потоке
                self.after(0, self.update_version_dropdown)

            except Exception as e:
                self.after(0, lambda: self.selected_version.set(self.t("no_versions")))
                self.after(0, lambda: self.version_dropdown.configure(values=[self.t("no_versions")]))
                error_msg = f"Failed to load versions:\n{str(e)}"
                print(error_msg)  # Для отладки

        thread = threading.Thread(target=fetch, daemon=True)
        thread.start()
        
    def update_version_dropdown(self):
        """Обновление выпадающего списка версий"""
        if not self.versions:
            self.selected_version.set(self.t("no_versions"))
            self.version_dropdown.configure(values=[self.t("no_versions")])
            return

        # Фильтрация версий
        if self.show_downloaded_var.get():
            # Только скачанные
            filtered = [v for v in self.versions if self.is_version_downloaded(v)]
            if not filtered:
                self.selected_version.set(self.t("no_downloaded"))
                self.version_dropdown.configure(values=[self.t("no_downloaded")])
                self.action_button.configure(text=self.t("select_version_text"), state="disabled",
                                            fg_color=("#6c757d", "#6c757d"))
                return
        else:
            filtered = self.versions

        # Формируем список с маркерами
        version_names = []
        for v in filtered:
            if self.is_version_downloaded(v):
                version_names.append(f"✅ {v['name']}")
            else:
                version_names.append(f"⬇ {v['name']}")

        self.version_dropdown.configure(values=version_names)

        # Выбираем первую версию
        if version_names:
            self.selected_version.set(version_names[0])
        
        self.update_action_button()
        
    def get_selected_version_info(self):
        """Получение информации о выбранной версии"""
        selected = self.selected_version.get()
        # Убираем маркеры из названия
        clean_selected = selected.replace("✅ ", "").replace("⬇ ", "")
        
        for v in self.versions:
            if v["name"] == clean_selected:
                return v
        return None
        
    def get_jar_path(self, version_info):
        """Получение пути к jar файлу версии"""
        if not version_info:
            return None
        version_folder = self.versions_dir / version_info['version']
        return version_folder / f"Mindustry-{version_info['version']}.jar"
        
    def is_version_downloaded(self, version_info):
        """Проверка, скачана ли версия"""
        if not version_info:
            return False
        jar_path = self.get_jar_path(version_info)
        return jar_path.exists() and jar_path.stat().st_size > 0
        
    def update_action_button(self):
        """Обновление текста и цвета кнопки действия"""
        version_info = self.get_selected_version_info()

        if not version_info:
            self.action_button.configure(
                text=self.t("select_version_text"),
                state="disabled",
                fg_color=("#6c757d", "#6c757d")
            )
            return

        if self.is_version_downloaded(version_info):
            self.action_button.configure(
                text=self.t("launch"),
                state="normal",
                fg_color=COLOR_SUCCESS,
                hover_color=COLOR_SUCCESS_HOVER
            )
        else:
            self.action_button.configure(
                text=self.t("download"),
                state="normal",
                fg_color=COLOR_PRIMARY,
                hover_color=COLOR_PRIMARY_HOVER
            )
        
    def action_click(self):
        """Обработка нажатия на кнопку действия"""
        if self.is_downloading:
            return
            
        version_info = self.get_selected_version_info()
        if not version_info:
            return
            
        if self.is_version_downloaded(version_info):
            self.launch_game()
        else:
            self.download_game()
            
    def download_game(self):
        """Скачивание игры"""
        version_info = self.get_selected_version_info()
        if not version_info:
            return
            
        self.is_downloading = True
        jar_path = self.get_jar_path(version_info)
        
        # Создаём папку для версии
        jar_path.parent.mkdir(exist_ok=True)
        
        # Получаем URL для скачивания
        try:
            url = f"https://github.com/Anuken/Mindustry/releases/download/{version_info['tag']}/Mindustry.jar"
            
            # Проверяем URL
            head_response = requests.head(url, allow_redirects=True, timeout=10)
            if head_response.status_code != 200:
                # Альтернативный URL
                url = f"https://github.com/Anuken/Mindustry/releases/download/{version_info['tag']}/Mindustry-{version_info['version']}.jar"
            
        except:
            pass
        
        def download():
            try:
                self.after(0, lambda: self.download_status.set(self.t("downloading")))

                response = requests.get(url, stream=True, timeout=30)
                response.raise_for_status()
                
                total_size = int(response.headers.get('content-length', 0))
                downloaded = 0
                
                with open(jar_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            
                            if total_size > 0:
                                progress = downloaded / total_size
                                self.after(0, lambda p=progress: self.progress.set(p))
                                mb_downloaded = downloaded / (1024 * 1024)
                                mb_total = total_size / (1024 * 1024)
                                self.after(0, lambda s=f"{mb_downloaded:.1f}/{mb_total:.1f} MB": 
                                          self.download_status.set(s))

                self.after(0, self.download_complete)

            except Exception as e:
                self.after(0, lambda: self.download_status.set(self.t("download_error")))
                self.after(0, lambda: messagebox.showerror("Error", f"{self.t('download_error')}:\n{e}"))
                if jar_path.exists():
                    jar_path.unlink()
            finally:
                self.is_downloading = False

        thread = threading.Thread(target=download, daemon=True)
        thread.start()
        
    def download_complete(self):
        """Завершение скачивания"""
        self.progress.set(1)
        self.download_status.set(self.t("download_complete"))
        self.update_action_button()
        messagebox.showinfo("Done", f"{self.t('download_complete')}\n{self.t('launch')}")

    def launch_game(self):
        """Запуск игры"""
        version_info = self.get_selected_version_info()
        if not version_info:
            return

        jar_path = self.get_jar_path(version_info)

        if not jar_path.exists():
            messagebox.showerror("Error", self.t("file_not_found"))
            self.update_action_button()
            return

        # Проверяем Java
        java_path = self.find_java()
        if not java_path:
            messagebox.showerror("Error", self.t("java_not_found"))
            return

        # Получаем настройки RAM
        try:
            ram_min = int(self.ram_min_var.get())
            ram_max = int(self.ram_max_var.get())
            fullscreen = self.fullscreen_var.get()
        except:
            ram_min = 512
            ram_max = 2048
            fullscreen = False

        # Сохраняем настройки
        self.config['ram_min'] = ram_min
        self.config['ram_max'] = ram_max
        self.config['fullscreen'] = fullscreen
        self.save_config()

        # Формируем аргументы JVM
        jvm_args = []
        
        # Аргументы RAM
        jvm_args.append(f"-Xms{ram_min}M")
        jvm_args.append(f"-Xmx{ram_max}M")
        
        # Полноэкранный режим
        if fullscreen:
            jvm_args.append("-Dorg.lwjgl.opengl.Display.allowFullscreenOpenGL=true")
        
        # Дополнительные аргументы из поля ввода
        extra_args = self.jvm_entry.get().strip()
        if extra_args:
            jvm_args.extend(extra_args.split())

        # Формируем команду
        cmd = [java_path] + jvm_args + ["-jar", str(jar_path)]

        self.download_status.set(self.t("launching"))

        try:
            self.current_process = subprocess.Popen(
                cmd,
                cwd=str(self.versions_dir)
            )
            self.download_status.set(self.t("launched"))
        except Exception as e:
            messagebox.showerror("Error", f"{self.t('launch_error')}:\n{e}")
            self.download_status.set("")
            
    def find_java(self):
        """Поиск установленной Java"""
        # Проверяем JAVA_HOME
        java_home = os.environ.get("JAVA_HOME")
        if java_home:
            java_exe = Path(java_home) / "bin" / "java.exe"
            if java_exe.exists():
                return str(java_exe)
        
        # Проверяем PATH
        try:
            result = subprocess.run(
                ["java", "-version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                return "java"
        except:
            pass
        
        # Стандартные пути установки
        possible_paths = [
            r"C:\Program Files\Java\jdk\bin\java.exe",
            r"C:\Program Files\Java\jre\bin\java.exe",
            r"C:\Program Files (x86)\Java\jdk\bin\java.exe",
            r"C:\Program Files (x86)\Java\jre\bin\java.exe",
        ]
        
        # Поиск в Program Files
        try:
            pf = Path(r"C:\Program Files")
            if pf.exists():
                for java_dir in pf.glob("**/bin/java.exe"):
                    if "java" in str(java_dir).lower():
                        return str(java_dir)
        except:
            pass
        
        for path in possible_paths:
            if Path(path).exists():
                return path
                
        return None
        
    def open_path(self):
        """Открытие папки лаунчера"""
        import os
        os.startfile(str(self.data_dir))
        
    def open_url(self, url):
        """Открытие URL в браузере"""
        import webbrowser
        webbrowser.open(url)
        
    def on_closing(self):
        """Закрытие приложения"""
        if self.current_process and self.current_process.poll() is None:
            if messagebox.askokcancel(self.t("exit_title"), self.t("exit_message")):
                self.destroy()
        else:
            self.destroy()


def is_first_run():
    """Проверка первого запуска"""
    user_name = getpass.getuser()
    data_dir = Path(f"C:/Users/{user_name}/MindLauncher")
    lang_file = data_dir / "lang.json"
    return not lang_file.exists()


if __name__ == "__main__":
    if is_first_run():
        # Первый запуск - запускаем мастер настройки
        wizard = FirstRunWizard()
        wizard.mainloop()
    else:
        # Повторный запуск - запускаем основной лаунчер
        app = MindustryLauncher()
        app.protocol("WM_DELETE_WINDOW", app.on_closing)
        app.mainloop()
