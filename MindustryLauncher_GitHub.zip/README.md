# ⬡ MindLauncher

Красивый и удобный лаунчер для игры **Mindustry** в стиле TLauncher.

![Preview](https://img.shields.io/badge/Windows-10%2F11-blue?style=for-the-badge)
![GitHub Release](https://img.shields.io/github/v/release/Feltyhides/MindustryLauncher?style=for-the-badge)
![License](https://img.shields.io/github/license/Feltyhides/MindustryLauncher?style=for-the-badge)

---

## ✨ Особенности

- 🌐 **Двуязычный интерфейс** — English / Русский
- ⚙️ **Настройка памяти** — Выделение RAM для игры
- 📦 **Автозагрузка версий** — Все версии с GitHub
- 🚀 **Быстрый запуск** — Оптимизированный код
- 💾 **Управление версиями** — Хранение в отдельной папке
- 🎨 **Современный UI** — В стиле TLauncher

---

## 📥 Установка

### Быстрый старт

1. Скачайте последний релиз: **[MindustryLauncher.exe](https://github.com/Feltyhides/MindustryLauncher/releases/latest/download/MindustryLauncher.exe)**
2. Запустите `.exe` файл
3. При первом запуске:
   - Выберите язык (English / Русский)
   - Проверьте наличие Java
   - Нажмите **"⏭ Завершить"**

---

## ⚙️ Требования

| Компонент | Требование |
|-----------|------------|
| **ОС** | Windows 10/11 (64-bit) |
| **Java** | Java 8 или выше |
| **RAM** | Минимум 2 GB |
| **Место** | 100 MB для лаунчера |

### 🔗 Установка Java

Если Java не установлена, скачайте с официального сайта:
- **[Oracle Java](https://www.oracle.com/java/technologies/downloads/)**
- **[Adoptium Temurin](https://adoptium.net/)** (бесплатная альтернатива)

---

## 🎮 Как использовать

### Основной интерфейс

| Кнопка | Действие |
|--------|----------|
| **⬇ СКАЧАТЬ** | Скачать выбранную версию игры |
| **▶ ЗАПУСТИТЬ** | Запустить скачанную версию |
| **📁 Открыть** | Открыть папку с данными лаунчера |

### Настройки памяти

По умолчанию:
- **Min:** 512 MB
- **Max:** 2048 MB

Рекомендации:

| Конфигурация ПК | Min RAM | Max RAM |
|-----------------|---------|---------|
| Слабый ПК (4 GB) | 512 MB | 1024 MB |
| Средний ПК (8 GB) | 1024 MB | 2048 MB |
| Мощный ПК (16+ GB) | 2048 MB | 4096 MB |

### Дополнительные аргументы JVM

Примеры для поля "JVM Arguments":
```
-Xmx2G -Xms1G -XX:+UseG1GC -Dfml.ignoreInvalidMinecraftCertificates=true
```

---

## 📁 Структура файлов

```
C:\Users\{user}\MindLauncher\
├── lang.json           ← Настройки (язык, RAM)
├── versions/           ← Версии игры
│   ├── v146/
│   │   └── Mindustry-v146.jar
│   └── v145/
│       └── Mindustry-v145.jar
└── java_installer.msi  ← (если скачивали Java)
```

---

## 🛠 Технологии

- **Python 3.14**
- **CustomTkinter** — современный GUI
- **PyInstaller** — компиляция в .exe
- **Requests** — HTTP запросы к GitHub API

---

## 📸 Скриншоты

### Главный экран
![Main Screen](https://via.placeholder.com/800x450/1E1E2E/FF6B35?text=MindLauncher+Main+Screen)

### Настройки памяти
![Settings](https://via.placeholder.com/800x450/1E1E2E/FF6B35?text=Memory+Settings)

> 💡 *Замените placeholder на реальные скриншоты вашего лаунчера*

---

## 🐛 Решение проблем

### Лаунчер не запускается
1. Убедитесь, что Windows 10/11
2. Проверьте антивирус (может блокировать .exe)
3. Запустите от имени администратора

### Java не найдена
1. Установите Java 8 или выше
2. Перезапустите лаунчер
3. Проверьте переменную окружения `JAVA_HOME`

### Ошибка загрузки версий
1. Проверьте подключение к интернету
2. GitHub API может быть недоступен временно
3. Попробуйте позже

---

## 📄 Лицензия

**MIT License** — свободное использование, модификация и распространение.

См. файл [LICENSE](LICENSE) для подробностей.

---

## 🤝 Вклад в проект

1. Fork репозиторий
2. Создайте ветку (`git checkout -b feature/AmazingFeature`)
3. Commit изменений (`git commit -m 'Add AmazingFeature'`)
4. Push в ветку (`git push origin feature/AmazingFeature`)
5. Откройте Pull Request

---

## 📞 Контакты

**Feltyhides** — автор проекта

- GitHub: [@Feltyhides](https://github.com/Feltyhides)
- Репозиторий: [MindustryLauncher](https://github.com/Feltyhides/MindustryLauncher)

---

<p align="center">
  <b>MindLauncher by Feltyhides</b> ⬡
  <br>
  <sub>Сделано с ❤️ для сообщества Mindustry</sub>
</p>
